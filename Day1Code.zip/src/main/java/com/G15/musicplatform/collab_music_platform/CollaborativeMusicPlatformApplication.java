package com.G15.musicplatform.collab_music_platform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollaborativeMusicPlatformApplication {

	public static void main(String[] args) {
		SpringApplication.run(CollaborativeMusicPlatformApplication.class, args);
	}

}
